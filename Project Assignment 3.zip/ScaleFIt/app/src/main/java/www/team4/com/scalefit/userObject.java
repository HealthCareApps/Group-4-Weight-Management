package www.team4.com.scalefit;

/**
 * Created by Andrew on 4/1/2016.
 */


public class userObject {

    private String firstName;
    private String lastName;
    private double age;
    private double weight;
    private double BMI;
    private double height;
//    private double armMeasure;
//    private double thighMeasure;
//    private double chestMeasure;
//    private double waistMeasure;
//    private double neckMeasure;
//    private double hipMeasure;

    public double getAge(){
        return age;
    }

    public double getWeight(){
        return weight;
    }

    public double getHeights(){
        return height;
    }

}
