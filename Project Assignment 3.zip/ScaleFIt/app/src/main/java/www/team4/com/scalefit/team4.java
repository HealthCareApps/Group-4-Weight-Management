package www.team4.com.scalefit;

/**
 * Created by Reaper on 3/9/2016.
 */
public class team4 {
    static String[] DetailList = {
            "Alexander Joiseus",
            "Richard Karl",
            "Katherine Arreaza",
            "Demetrius Dukes",
            "Andrew Barbosa"
    };

    static String[] Details = {
            "Alexander Joiseus\n\n Lead Application Developer. Senior in Computer Science & " +
                    "Computer Engineering",

            "Richard Karl\n\n A junior working towards Bachelor's in Computer\n" +
                    "Engineering. I enjoy the challenge of programming (currently know C,\n" +
                    "C++, Assembly, and working on Java and XML from Software/Hardware),\n" +
                    "playing sudoku (mainly the harder difficulties) , playing the drums\n" +
                    "(I'm self taught and play by ear and figured out how to play by\n" +
                    "listening to the beats and grooves in songs) and video games in my\n" +
                    "spare time.",

            "Katherine Arreaza\n\n I am a graduate Nursing student , working towards " +
                    "becoming a Nurse Practioner. I currently work full-time as a trauma intensive "
                    + "care nurse. My hobbies include working out and just spending time with " +
                    "family and friends. I also like going to the beach and going to the movies.",

            "Demetrius Dukes\n\n Lead Graphical Artist",

            "Andrew Barbosa \n\n Application Developer, great programmer. Overall Really Cool guy"
    };
}
