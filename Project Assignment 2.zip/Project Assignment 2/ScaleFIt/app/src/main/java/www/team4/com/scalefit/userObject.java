package www.team4.com.scalefit;

/**
 * Created by Andrew on 4/1/2016.
 */


public class userObject {

    private String firstName;
    private String lastName;
    private String userEmail;
    private String userPassword;
    private int age;
    private int DOB;
    private int weight;
    private int BMI;
    private float height;
    private float armMeasure;
    private float thighMeasure;
    private float chestMeasure;
    private float waistMeasure;
    private float neckMeasure;
    private float hipMeasure;


}
